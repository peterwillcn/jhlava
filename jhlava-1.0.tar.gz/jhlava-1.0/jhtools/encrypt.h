#include <openssl/aes.h>

extern char* jhencrypt(const char* oristr);
extern char* jhdecrypt(const char* encryptstr);
